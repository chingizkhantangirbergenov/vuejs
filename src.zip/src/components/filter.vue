<template>
	<body></body>
</template>

<style>
	body {
		background: url("../assets/back.png");
    height: 3000px;
    }

</style>